open_weather_token = "openwether_token"
tg_bot_token = "your_bot_token"